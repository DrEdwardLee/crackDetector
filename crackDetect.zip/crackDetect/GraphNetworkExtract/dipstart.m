addpath('D:\Program Files\DIPimage 2.8.1\common\dipimage');
dip_initialise;
dipsetpref('ImageFilePath', 'D:\Program Files\DIPimage 2.8.1\images');
