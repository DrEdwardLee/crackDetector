

clc
clear 
close all;
%% load paths
currentFolder = pwd;
addpath(genpath(currentFolder))
run dipstart.m 

%% Choise a Image for detection 
[filename,pathname]=uigetfile({'*.jpg;*.bmp;*.tif;*.pgm;*.png;*.gif','All Image Files';'*.*','All Files'});
Img = imread([pathname,filename]);
imgPath=strcat(pathname,filename);
disp(['The processing image path is - ',  imgPath ]);
% clear filename pathname imgPath

%% step 1: Percolating the  input Image
if ~isequal(ndims(Img), 2)
    Img = rgb2gray(Img);
end
Img = double(Img);  
  

%% step 1: Preprocessing (including illumination Balance, denoising, downsampling)
[ Imgcorrected ] = illuminationBalance( Img ); 

ParamInfor.winSize = 2;
ParamInfor.MapType = 'MinValue';   % ParamInfor.MapType = 'MaxValue';
ParamInfor.verbose = true;
CellMap = preProcessing_GCA(Img, ParamInfor);
ImgCell = uint8(CellMap.minimum);  % ImgCell = uint8(CellMap.maximum);
  
figure(), 
subplot(1, 2, 1),  imshow(Img,[]),            title('Input Image'); 
subplot(1, 2, 2);  imshow(ImgCell, []);       title('Grid Cell Image'); 

%% step 2: multi-scale curvilinear enhancement  
Options.sigma1 = [2 7];         Options.sigma1_step = 1;
Options.sigma2 =  1.5;       
Options.k = [0 0.1];         Options.k_step = 0.025;
Options.angle = [0 180];        Options.angle_step = 15;  
OutEnhenced = CurvilinearEnhence( ImgCell, Options );
ImgEnhenced = OutEnhenced.new;
ImgMask = OutEnhenced.mask;

figure(), 
subplot(1, 2, 1),  imshow(Img,[]),            title('Input Image'); 
subplot(1, 2, 2);  imshow(ImgEnhenced, []);       title('Grid Cell Image'); 
%% step 3: Graph Extraction 
winSize = 4; 
Imgseed = SeedFinding(ImgEnhenced, ImgMask, winSize) ;
[x, y] = find( Imgseed==1 ); seedList = [x, y];
ImgGraph = GraphExtract( ImgCell, ImgEnhenced, seedList );
 

%% step 4: Graph network refinement using Path Classify   
[ PathList, PathSaliency, PathContrast, ImgJunct ] = PathFeatures( ImgEnhenced, ImgMask, ImgGraph );

Tcontrast = 0.28;
[ CrackPath ] = PathClassify( PathList, PathSaliency, PathContrast, ImgJunct, Tcontrast );

minArea = 15; 
minDist = 25;
CrackPath = RemoveIsolatePath( CrackPath, minArea, minDist ); 


%% step 7: iterative path growing 
minLength = 10;
neighDist = 15;
Tp = 1.0; 
ImgCrack = IterPathGrowing( uint8(ImgCell), CrackPath, minLength, neighDist, Tp ); 


 
 