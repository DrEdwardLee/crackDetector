
clc
clear ;
close all


%% load paths
currentFolder = pwd;
addpath(genpath(currentFolder)) 
checkMex;% compile poly2d.cpp if neccesary. You need to set up your compiler configuration with "mex -setup" beforehand.

%% Choise a Image for detection 
[filename,pathname]=uigetfile({'*.jpg;*.bmp;*.tif;*.png;*.gif','All Image Files';'*.*','All Files'});
Img = imread([pathname,filename]);
imgPath=strcat(pathname,filename);
disp(['The processing image path is - ',  imgPath ]);
clear filename pathname imgPath

if ~isequal(ndims(Img), 2)
    Img = rgb2gray(Img);
end
% Img = double(imresize(Img, 0.35, 'nearest'));
% Img = double(Img);
    
tic
[VignettingCorrected, Vignetting]=vignCorrection_nonPara(Img);
toc

% show results
figure; 
subplot(1,3,1); imshow(Img,[]), title('Input Image');
subplot(1,3,2); imshow(Vignetting,[]); title('Estimated Vignetting')
subplot(1,3,3); imshow(VignettingCorrected,[]); title('Vignetting-Corrected Image')












