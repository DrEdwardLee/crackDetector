function myMEX( )

setenv('MW_MINGW64_LOC','C:\TDM-GCC-64');
eval(['mex -setup:''',fullfile(matlabroot,'bin\win64\mexopts\mingw64.xml'),''' C']) % C
eval(['mex -setup:''',fullfile(matlabroot,'bin\win64\mexopts\mingw64_g++.xml'),''' C']) % C++


mex poly2d.cpp

end

