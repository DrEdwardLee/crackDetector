function ccc()
close all; clc; clear;