function cc()
close all; clc;