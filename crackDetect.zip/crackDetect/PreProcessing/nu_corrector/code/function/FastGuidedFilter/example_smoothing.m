% example: edge-preserving smoothing

 
clc
clear 
close all;

%% Choise a Image for detection 
[filename,pathname]=uigetfile({'*.jpg;*.bmp;*.tif;*.png;*.gif','All Image Files';'*.*','All Files'});
I = imread([pathname,filename]);
IPath=strcat(pathname,filename);
disp(['The processing image path is - ',  IPath ]);
clear filename pathname IPath

if ~isequal(ndims(I), 2)
    I = rgb2gray(I);
end
I = double(I)/ 255;

p = I;
r = 4;
eps = 0.4^2; % try eps=0.1^2, 0.2^2, 0.4^2

tic;
q = guidedfilter(I, p, r, eps);
toc;

s = 4; % sampling ratio
tic;
q_sub = fastguidedfilter(I, p, r, eps, s);
toc;

figure();
imshow([I, q, q_sub], [0, 1]);
